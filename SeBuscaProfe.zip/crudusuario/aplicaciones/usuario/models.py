from django.db import models

# Create your models here.
class Usuario(models.Model):
    codigo=models.CharField(primary_key=True,max_length=6)
    nombre=models.CharField(max_length=50)
    apellido=models.CharField(max_length=50)

    def __str__(self):
        texto = "{0} {1}"
        return texto.format(self.nombre, self.apellido)

class Actividades(models.Model):
    id_actividad = models.CharField(primary_key=True, max_length=30)
    id_tipo_actividad = models.ForeignKey('TipoActividades', models.DO_NOTHING, db_column='id_tipo_actividad')
    id_administrador = models.ForeignKey('Administradores', models.DO_NOTHING, db_column='id_administrador')
    fecha_actividad = models.DateField()
    fecha_solici = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'actividades'


class Administradores(models.Model):
    id_administrador = models.BigIntegerField(primary_key=True)
    rut = models.ForeignKey('Usuarios', models.DO_NOTHING, db_column='rut')

    class Meta:
        managed = False
        db_table = 'administradores'


class AlumnoClase(models.Model):
    id_alumno = models.OneToOneField('Alumnos', models.DO_NOTHING, db_column='id_alumno', primary_key=True)
    id_clase = models.ForeignKey('Clases', models.DO_NOTHING, db_column='id_clase')
    asistencia = models.CharField(max_length=1)
    fecha_pago = models.DateField()
    valor_pago = models.BigIntegerField()
    comision = models.BigIntegerField()
    encuesta = models.CharField(max_length=1)
    nota = models.BigIntegerField(blank=True, null=True)
    fecha_calif = models.DateField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'alumno_clase'
        unique_together = (('id_alumno', 'id_clase'),)


class Alumnos(models.Model):
    id_alumno = models.BigIntegerField(primary_key=True)
    rut = models.ForeignKey('Usuarios', models.DO_NOTHING, db_column='rut')

    class Meta:
        managed = False
        db_table = 'alumnos'


class Clases(models.Model):
    id_clase = models.BigIntegerField(primary_key=True)
    valor = models.BigIntegerField()
    id_materia = models.ForeignKey('Materias', models.DO_NOTHING, db_column='id_materia')
    fecha_clase = models.DateField()
    hora_clase = models.DateField()
    id_profesor = models.ForeignKey('Profesores', models.DO_NOTHING, db_column='id_profesor')

    class Meta:
        managed = False
        db_table = 'clases'


class Conexiones(models.Model):
    id_conexion = models.BigIntegerField(primary_key=True)
    rut = models.ForeignKey('Usuarios', models.DO_NOTHING, db_column='rut')
    duracion = models.DateField()
    fecha_conexion = models.DateField()
    carga_max = models.BigIntegerField()
    fecha_carga_max = models.DateField()
    hora_inicio = models.DateField()
    hora_finalizada = models.DateField()

    class Meta:
        managed = False
        db_table = 'conexiones'


class Especialidades(models.Model):
    id_especialidad = models.BigIntegerField(primary_key=True)
    tipo_espec = models.CharField(max_length=20)
    nombre_espec = models.CharField(max_length=30)
    titulo = models.CharField(max_length=40, blank=True, null=True)
    certificacion = models.CharField(max_length=40, blank=True, null=True)
    curso = models.CharField(max_length=40, blank=True, null=True)
    mencion = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'especialidades'


class Materias(models.Model):
    id_materia = models.BigIntegerField(primary_key=True)
    nombre = models.CharField(max_length=25)
    tipo = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'materias'


class Plataforma(models.Model):
    id_plat = models.BigIntegerField(primary_key=True)
    nombre_plat = models.CharField(max_length=20)

    class Meta:
        managed = False
        db_table = 'plataforma'


class PlataformaClase(models.Model):
    id_plat = models.OneToOneField(Plataforma, models.DO_NOTHING, db_column='id_plat', primary_key=True)
    id_clase = models.ForeignKey(Clases, models.DO_NOTHING, db_column='id_clase')

    class Meta:
        managed = False
        db_table = 'plataforma_clase'
        unique_together = (('id_plat', 'id_clase'),)


class Profesores(models.Model):
    id_profesor = models.BigIntegerField(primary_key=True)
    rut = models.ForeignKey('Usuarios', models.DO_NOTHING, db_column='rut')
    id_especialidad = models.ForeignKey(Especialidades, models.DO_NOTHING, db_column='id_especialidad')
    id_materia = models.ForeignKey(Materias, models.DO_NOTHING, db_column='id_materia')

    class Meta:
        managed = False
        db_table = 'profesores'


class TipoActividades(models.Model):
    id_tipo_actividad = models.BigIntegerField(primary_key=True)
    nombre_tipo_act = models.CharField(max_length=30)
    descripcion_tipo_act = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'tipo_actividades'


class Usuarios(models.Model):
    rut = models.BigIntegerField(primary_key=True)
    nombre_usuario = models.CharField(max_length=30)
    apellido_usuario = models.CharField(max_length=30)
    sexo = models.CharField(max_length=20)
    fecha_nac = models.DateField()
    direccion = models.CharField(max_length=50)
    num_tel = models.BigIntegerField()
    permiso = models.CharField(max_length=20)
    correo = models.CharField(max_length=50)
    contrasenha = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'usuarios'
