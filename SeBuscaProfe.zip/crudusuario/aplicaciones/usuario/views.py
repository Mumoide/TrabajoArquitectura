from datetime import datetime
from pyexpat.errors import messages
from django.shortcuts import render, redirect, get_object_or_404

from .models import Usuario, Clases, Materias, Profesores
from django.contrib import messages
from django.db import connection

# Create your views here.
def clases(request):
    listaClases = Clases.objects.all()
    messages.success(request, 'Clases listadas')

    return render(request, "gestionClases.html", {"clases": listaClases})

def inicio(request):
    return render(request, "inicio.html")

def alumnos(request):
    # print(listado_alumnos())
    data = {
        'alumnos': listado_alumnos(),
        'alumnosxclases': listado_alumnos_porclases()
    }
    return render(request, "alumnos.html", data)

def registrarUsuario(request): 
    codigo=request.POST['txtCodigo']
    nombre=request.POST['txtNombre']
    apellido=request.POST['txtApellido']

    usuario=Usuario.objects.create(codigo=codigo, nombre=nombre, apellido=apellido)
    messages.success(request, 'Clase registrada')
    return redirect('/clases')

def registrarClase(request): 
    id_clase = request.POST['txtClase']
    valor = request.POST['txtValor']
    id_materia = request.POST['txtidMateria']
    fecha_clase = datetime.strptime(request.POST['txtFecha'], '%d-%m-%Y').date()# request.POST['txtCodigo']
    hora_clase = datetime.strptime(request.POST['txtHora'], '%d-%m-%Y').date()# request.POST['txtCodigo']
    id_profesor = request.POST['txtProfesor']
    materia = get_object_or_404(Materias, id_materia=id_materia)
    profesor = get_object_or_404(Profesores, id_profesor=id_profesor)

    usuario=Clases.objects.create( id_clase=id_clase, valor=valor, id_materia=materia,fecha_clase=fecha_clase,hora_clase=hora_clase,id_profesor=profesor)
    messages.success(request, 'Clase registrada')
    return redirect('/clases')

def eliminarClases(request, id_clase):
    clase = Clases.objects.get(id_clase=id_clase)
    clase.delete()
    messages.success(request, 'Clase eliminada')

    return redirect('/clases')

def edicionClases(request,id_clase):
    clase = Clases.objects.get(id_clase=id_clase)
    return render(request, "edicionClases.html", {"clase": clase})

def editarUsuario(request):
    id_clase=request.POST['txtIdClase']
    fecha_clase=request.POST['txtFecha']
    valor=request.POST['txtValor']
    fecha_clase=datetime.strptime(fecha_clase, '%d-%m-%Y').date()

    clase = Clases.objects.get(id_clase=id_clase)
    clase.fecha_clase = fecha_clase
    clase.valor = valor
    clase.save()
    messages.success(request, 'Clase modificada')

    return redirect('/clases')

def listarClases(request):
    
    clases = Clases.objects.all()
    print(request.user)
    # id_profesor = request.user.id
    # clases = Clases.objects.filter()
    # clases = Clases.objects.filter(id_profesor=1)
    return render(request, "listar-clases.html", {"clases":clases})

def listado_alumnos():
    django_cursor = connection.cursor()
    cursor = django_cursor.connection.cursor()
    out_cur = django_cursor.connection.cursor()

    cursor.callproc("SP_LISTAR_ALUMNOS_X_CLASES", [out_cur])

    lista = []
    for fila in out_cur:
        lista.append(fila)
    
    return lista

def listado_alumnos_porclases():
    django_cursor = connection.cursor()
    cursor = django_cursor.connection.cursor()
    out_cur = django_cursor.connection.cursor()

    cursor.callproc("SP_CANT_ALUMNOS_X_CLASES", [out_cur])

    lista = []
    for fila in out_cur:
        lista.append(fila)
    
    return lista