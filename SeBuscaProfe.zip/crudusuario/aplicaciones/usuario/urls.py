from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio),
    path('registrarUsuario/', views.registrarUsuario, name='registrarUsuario'),
    path('registrarClase/', views.registrarClase, name='registrarClase'),
    path('clases/eliminarClases/<id_clase>', views.eliminarClases, name='eliminarClases'),
    path('clases/edicionClases/<id_clase>', views.edicionClases, name='edicionClases'),
    path('editarUsuario/', views.editarUsuario, name='editarUsuario'),
    path('clases/', views.clases, name='clases'),
    path('listar-clases/', views.listarClases, name='listar-clases'),
    path('alumnos/', views.alumnos, name='alumnos' )
    ]
    