from django.contrib import admin
from .models import Clases

# Register your models here.
admin.site.register(Clases)