
  CREATE OR REPLACE PROCEDURE SP_CANT_ALUMNOS_X_CLASES (alumnos out SYS_REFCURSOR)
IS

BEGIN
 OPEN ALUMNOS FOR SELECT c.id_materia, m.nombre, c.id_clase, count(a.id_alumno) as cant_alumno
                 FROM clases c join materias m
                 on c.id_materia = m.id_materia
                 join alumno_clase a
                 on c.id_clase = a.id_clase
                 group by c.id_materia, m.nombre, c.id_clase;
END;

/