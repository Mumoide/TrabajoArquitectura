  CREATE OR REPLACE  PROCEDURE SP_LISTAR_ALUMNOS_X_CLASES (alumnos out SYS_REFCURSOR)
IS

BEGIN
 OPEN ALUMNOS FOR SELECT c.id_materia, m.nombre, c.id_clase, u.nombre_usuario
                 FROM clases c join materias m
                 on c.id_materia = m.id_materia
                 join alumno_clase a
                 on c.id_clase = a.id_clase
                 join alumnos al
                 on a.id_alumno = al.id_alumno
                 join usuarios u
                 on al.rut = u.rut
                 ORDER BY C.ID_CLASE;
END;

/